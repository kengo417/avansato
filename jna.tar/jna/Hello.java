import java.sql.*;

public class Hello
{
    void  Hello()
    {
    }

    public void execute()
    {
        try
        {
            System.out.println("1 Hello");
            Thread.sleep(10000);
            System.out.println("2 Hello");
        } catch(InterruptedException e){}
    }

    public static void main(String[] args)
    {
        Hello get = new Hello();
        get.execute();
    }
}

