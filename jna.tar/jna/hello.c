#include <stdio.h>
#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int hello(int c, wchar_t *key)
{
    char mbs[1024];

    if(wcstombs(mbs, key, sizeof(mbs)) == -1)
    {
        return 9;
    }
    printf("hello(%s)\n", mbs);



    //wprintf(L"hello(%ls)\n", key);


    return -1;
}
