gcc -fPIC -shared -o libhello.so hello.c
javac -cp jna.jar HelloJNA.java
java -d64 -cp ./:./libhello.so:./jna.jar HelloJNA
