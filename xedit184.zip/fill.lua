--
-- xedit.exe �p Lua�X�N���v�g�T���v��
--
-- �r�b�O�G���f�B�A�� 4 �o�C�g�� 0x00 �` 0xff �Ԓn�܂ł�
-- �C���N�������g�l�Ŗ��߂����
--
-- usage : fill.lua [start size [data]]
--

function ins_b4(addr, val)
	xedit.set(addr + 3, val)
	xedit.set(addr + 2, val / 0x100)
	xedit.set(addr + 1, val / 0x10000)
	xedit.set(addr + 0, val / 0x1000000)
end

function ins_l4(addr, val)
	xedit.set(addr + 0, val)
	xedit.set(addr + 1, val / 0x100)
	xedit.set(addr + 2, val / 0x10000)
	xedit.set(addr + 3, val / 0x1000000)
end

function ins_b2(addr, val)
	xedit.set(addr + 1, val)
	xedit.set(addr + 0, val / 0x100)
end

function ins_l2(addr, val)
	xedit.set(addr + 0, val)
	xedit.set(addr + 1, val / 0x100)
end

if (#arg >= 3) then
	data = tonumber(arg[3], 16);
else
	data = 0
end

if (#arg >= 2) then
	start = tonumber(arg[1], 16);
	len = tonumber(arg[2], 16);
else
	start, len = xedit.get_sel()
	if (len == 0) then
		len = 0xff
	end
end

fill = 2
big = 0
mask = 0x400
print(string.format(
	"fill start = %x, len = %x, initval = %x", start, len, data))

for addr = start, start + len, fill
do
	if (fill == 4) then
		if (big == 1) then
			ins_b4(addr, data)
		else
			ins_l4(addr, data)
		end
	else
		if (big == 1) then
			ins_b2(addr, data)
		else
			ins_l2(addr, data)
		end
	end
	print(string.format("addr = 0x%02x, data = 0x%02x", addr, data))
	data = data + 1
	if (mask ~= 0) then
		data = data % mask
	end
end
print(string.format("size = 0x%x", xedit.size()))

